# خطاطتي v7 — مشروع APK

هذا المشروع يحوّل واجهة خطاطتي v7 المجانية إلى تطبيق Android باستخدام WebView.

## المتطلبات للبناء
- Android Studio حديث
- Android SDK 35
- JDK 17 أو أحدث مناسب لإصدار Android Gradle Plugin

## البناء
افتح المجلد في Android Studio ثم اختر Build > Build APK(s).

ملف APK الناتج سيكون عادة داخل:
`app/build/outputs/apk/debug/app-debug.apk`

التطبيق لا يحتاج API مدفوعًا. البيانات التي تعتمد على الواجهة المحلية تبقى داخل التطبيق/الجهاز.


## بناء APK من الهاتف
راجع الملف `BUILD_APK_FROM_PHONE_AR.md`، ويوجد Workflow جاهز داخل `.github/workflows/build-apk.yml`.
